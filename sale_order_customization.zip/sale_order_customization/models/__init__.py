from . import sale_order
from . import res_config_settings
from . import stock_move